export class MyProduct{
    prdId:Number;
    prdName:String;
    prdCost:Number;
}