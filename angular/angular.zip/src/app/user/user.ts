export class User{
    id:Number;
    name:String;
    salary:Number;
}